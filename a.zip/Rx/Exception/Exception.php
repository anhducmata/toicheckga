<?php

declare(strict_types = 1);

namespace Rx\Exception;

class Exception extends \Exception
{
}
