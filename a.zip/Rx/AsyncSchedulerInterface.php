<?php

namespace Rx;

interface AsyncSchedulerInterface extends SchedulerInterface
{
}